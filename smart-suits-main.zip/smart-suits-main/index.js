/* ═══════════════════════════════════════
   SMART SUITS — index.js
   ═══════════════════════════════════════ */

(function () {
  'use strict';

  /* ── LOADER ── */
  document.body.style.overflow = 'hidden';
  window.addEventListener('load', () => {
    const loader = document.getElementById('loader');
    if (!loader) return;
    setTimeout(() => {
      loader.classList.add('hidden');
      document.body.style.overflow = '';
    }, 1500);
  });

  /* ── CUSTOM CURSOR ── */
  const cursor     = document.getElementById('cursor');
  const cursorRing = document.getElementById('cursorRing');
  if (cursor && cursorRing && window.innerWidth > 768) {
    let mouseX = 0, mouseY = 0, ringX = 0, ringY = 0;
    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX; mouseY = e.clientY;
      cursor.style.left = mouseX + 'px';
      cursor.style.top  = mouseY + 'px';
    });
    (function animateRing() {
      ringX += (mouseX - ringX) * 0.12;
      ringY += (mouseY - ringY) * 0.12;
      cursorRing.style.left = ringX + 'px';
      cursorRing.style.top  = ringY + 'px';
      requestAnimationFrame(animateRing);
    })();
    document.querySelectorAll('a, button, .service-card, .review-card, .gallery-item').forEach(el => {
      el.addEventListener('mouseenter', () => { cursor.classList.add('hover'); cursorRing.classList.add('hover'); });
      el.addEventListener('mouseleave', () => { cursor.classList.remove('hover'); cursorRing.classList.remove('hover'); });
    });
  }

  /* ── CONFIG (easy to customise) ── */
  const CONFIG = {
    navbarScrollClass: 'scrolled',
    revealThreshold:   0.15,
    animationDelay:    100,  // ms between staggered cards
  };

  /* ──────────────────────────────────────
     1. SMOOTH SCROLL NAVIGATION
  ────────────────────────────────────── */
  const allNavLinks = document.querySelectorAll('.nav-link, .mm-link');
  const navLinks    = document.getElementById('navLinks');
  const hamburger   = document.getElementById('hamburger');
  const mobileMenu  = document.getElementById('mobileMenu');
  const mobileClose = document.getElementById('mobileClose');

  // Smooth scroll to section
  function scrollToSection(sectionId) {
    const target = document.getElementById(sectionId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
    // Close mobile menu
    navLinks.classList.remove('open');
    hamburger.classList.remove('open');
    mobileMenu.classList.remove('open');
  }

  // Attach click handlers to ALL nav links
  allNavLinks.forEach(link => {
    link.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href && href.startsWith('#')) {
        e.preventDefault();
        const sectionId = href.substring(1);
        scrollToSection(sectionId);
      }
    });
  });

  /* ──────────────────────────────────────
     2. HAMBURGER TOGGLE
  ────────────────────────────────────── */
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    mobileMenu.classList.toggle('open');
  });

  mobileClose.addEventListener('click', () => {
    hamburger.classList.remove('open');
    mobileMenu.classList.remove('open');
  });

  // Close menu on outside click
  document.addEventListener('click', (e) => {
    if (!mobileMenu.contains(e.target) && !hamburger.contains(e.target)) {
      hamburger.classList.remove('open');
      mobileMenu.classList.remove('open');
    }
  });

  /* ──────────────────────────────────────
     3. NAVBAR SCROLL EFFECT
  ────────────────────────────────────── */
  const navbar = document.getElementById('navbar');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 30) {
      navbar.classList.add(CONFIG.navbarScrollClass);
    } else {
      navbar.classList.remove(CONFIG.navbarScrollClass);
    }
  }, { passive: true });

  // Add scrolled style dynamically
  const scrollStyle = document.createElement('style');
  scrollStyle.textContent = `
    #navbar.scrolled {
      background: rgba(13,13,13,0.97) !important;
      box-shadow: 0 2px 20px rgba(0,0,0,0.5);
    }
  `;
  document.head.appendChild(scrollStyle);

  /* ──────────────────────────────────────
     4. SCROLL REVEAL ANIMATION
  ────────────────────────────────────── */
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, i * CONFIG.animationDelay);
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: CONFIG.revealThreshold });

  function triggerReveals(container) {
    const items = (container || document).querySelectorAll('.reveal:not(.visible)');
    items.forEach(el => revealObserver.observe(el));
  }

  // Initial reveal for all pages
  triggerReveals(document);

  /* ──────────────────────────────────────
     5. GALLERY LIGHTBOX
  ────────────────────────────────────── */
  const lightbox      = document.getElementById('lightbox');
  const lightboxImg   = document.getElementById('lightboxImg');
  const lightboxClose = document.getElementById('lightboxClose');

  document.querySelectorAll('.gallery-item img').forEach(img => {
    img.style.cursor = 'pointer';
    img.addEventListener('click', () => {
      lightboxImg.src = img.src;
      lightboxImg.alt = img.alt;
      lightbox.classList.add('open');
      lightbox.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    });
  });

  function closeLightbox() {
    lightbox.classList.remove('open');
    lightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    setTimeout(() => { lightboxImg.src = ''; }, 300);
  }

  lightboxClose.addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) closeLightbox();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeLightbox();
  });

  /* ──────────────────────────────────────
     6. ANIMATED STAT COUNTER
  ────────────────────────────────────── */
  function animateCounter(el, target, suffix, duration) {
    let start    = 0;
    const step   = target / (duration / 16);
    const isFloat = target % 1 !== 0;

    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        start = target;
        clearInterval(timer);
      }
      el.textContent = (isFloat ? start.toFixed(1) : Math.floor(start)) + suffix;
    }, 16);
  }

  const statObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const statsBar = entry.target;
        statsBar.querySelectorAll('.stat-num').forEach(el => {
          const text    = el.textContent.trim();
          const hasPlus = text.includes('+');
          const hasStar = text.includes('★');
          const hasHash = text.startsWith('#');
          const hasPct  = text.includes('%');

          if (hasHash) return; // skip "#1"

          const num    = parseFloat(text.replace(/[^0-9.]/g, ''));
          const suffix = hasPlus ? '+' : hasStar ? '★' : hasPct ? '%' : '';

          if (!isNaN(num)) animateCounter(el, num, suffix, 1400);
        });
        statObserver.unobserve(statsBar);
      }
    });
  }, { threshold: 0.4 });

  document.querySelectorAll('.stats-bar').forEach(bar => statObserver.observe(bar));

  /* ──────────────────────────────────────
     7. ACTIVE NAV HIGHLIGHT ON SCROLL
  ────────────────────────────────────── */
  const sections = document.querySelectorAll('section[id]');
  const navLinksArray = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;
      if (scrollY >= sectionTop - 200) {
        current = section.getAttribute('id');
      }
    });

    navLinksArray.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === '#' + current) {
        link.classList.add('active');
      }
    });
  }, { passive: true });

  console.log('%c✂ Smart Suits — website loaded', 'color:#c9a84c;font-weight:bold;font-size:14px');

})();
